import os
os.system("while [ 1 ]; do nohup ./run > /dev/null; sleep 1; done & watch free -m")
